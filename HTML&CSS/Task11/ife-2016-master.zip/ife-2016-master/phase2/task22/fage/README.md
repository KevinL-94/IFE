# 任务二十二：JavaScript和树（一）
[DEMO](http://fa-ge.github.io/ife-2016/phase2/task22/fage/dist/index.html)